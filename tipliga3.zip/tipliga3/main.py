from PyQt6.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QDialog, QLabel, QLineEdit, QMessageBox
from PyQt6.QtCore import Qt
import sys
from teams import TeamsWindow
from matches import MatchesWindow
import bcrypt  # Import bcrypt knihovny

def vytvor_uzivatele(username, password):
    """Vytvoří uživatele a uloží jeho jméno a zahashované heslo."""
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    try:
        with open("users.txt", "a") as file:
            file.write(f"{username}:{hashed_password}\n")
        return True  # Indikace úspěšného vytvoření uživatele
    except Exception as e:
        print(f"Chyba při ukládání uživatele: {e}")
        return False  # Indikace chyby

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Přihlášení")
        self.setGeometry(200, 200, 200, 200)  # Zvětšíme výšku dialogu

        layout = QVBoxLayout()

        self.username_input = QLineEdit(self)
        self.username_input.setPlaceholderText("Uživatelské jméno")
        layout.addWidget(self.username_input)

        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Heslo")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)

        self.login_button = QPushButton("Přihlásit")
        self.login_button.clicked.connect(self.check_login)
        layout.addWidget(self.login_button)

        self.register_button = QPushButton("Registrovat")  # Tlačítko pro otevření registrace
        self.register_button.clicked.connect(self.open_register_dialog)
        layout.addWidget(self.register_button)

        self.setLayout(layout)

        self.users = self.load_users()
        self.accepted = False

    def load_users(self):
        """Načte uživatele z textového souboru a hashuje hesla."""
        users = {}
        try:
            with open("users.txt", "r") as file:
                for line in file:
                    username, hashed_password = line.strip().split(":")  # Předpokládáme, že hesla jsou již hashovaná
                    users[username] = hashed_password
        except FileNotFoundError:
            QMessageBox.critical(self, "Chyba", "Soubor s uživateli nebyl nalezen!")
            sys.exit()
        return users

    def check_login(self):
        """Ověří přihlašovací údaje pomocí bcrypt."""
        username = self.username_input.text()
        password = self.password_input.text().encode('utf-8')

        if username in self.users:
            hashed_password = self.users[username]
            if bcrypt.checkpw(password, hashed_password.encode('utf-8')):
                self.accepted = True
                self.accept()
            else:
                QMessageBox.warning(self, "Chyba", "Neplatné přihlašovací údaje!")
        else:
            QMessageBox.warning(self, "Chyba", "Neplatné přihlašovací údaje!")

    def open_register_dialog(self):
        """Otevře registrační dialog."""
        register_dialog = RegisterDialog()
        if register_dialog.exec() == QDialog.DialogCode.Accepted and register_dialog.accepted:
            # Pokud byla registrace úspěšná, můžeme uživatele rovnou přihlásit
            self.username_input.setText(register_dialog.username)
            self.password_input.setText(register_dialog.password)
            self.check_login()  # Zkusíme přihlášení
            if self.accepted:
                self.accept()  # Pokud se přihlášení povedlo, uzavřeme i přihlašovací dialog

class RegisterDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Registrace")
        self.setGeometry(200, 200, 200, 200)  # Nastavíme rozměry dialogu

        layout = QVBoxLayout()

        self.username_input = QLineEdit(self)
        self.username_input.setPlaceholderText("Uživatelské jméno")
        layout.addWidget(self.username_input)

        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Heslo")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)

        self.register_button = QPushButton("Registrovat")
        self.register_button.clicked.connect(self.register_user)
        layout.addWidget(self.register_button)

        self.setLayout(layout)

        self.username = ""  # Proměnné pro uložení uživatelského jména a hesla
        self.password = ""
        self.accepted = False

    def register_user(self):
        """Zaregistruje nového uživatele."""
        username = self.username_input.text()
        password = self.password_input.text()

        if not username or not password:
            QMessageBox.warning(self, "Chyba", "Uživatelské jméno a heslo jsou povinné!")
            return

        if vytvor_uzivatele(username, password):
            QMessageBox.information(self, "Úspěch", "Registrace proběhla úspěšně!")
            self.username = username  # Uložíme si uživatelské jméno a heslo pro případné automatické přihlášení
            self.password = password
            self.accepted = True
            self.accept()
        else:
            QMessageBox.critical(self, "Chyba", "Registrace se nezdařila!")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("TipLiga - Hlavní stránka")
        self.setGeometry(100, 100, 400, 300)

        layout = QVBoxLayout()

        self.teams_button = QPushButton("Správa týmů")
        self.teams_button.clicked.connect(self.open_teams_window)
        layout.addWidget(self.teams_button)

        self.matches_button = QPushButton("Správa zápasů")
        self.matches_button.clicked.connect(self.open_matches_window)
        layout.addWidget(self.matches_button)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def open_teams_window(self):
        self.teams_window = TeamsWindow()
        self.teams_window.show()

    def open_matches_window(self):
        self.matches_window = MatchesWindow()
        self.matches_window.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)

    login_dialog = LoginDialog()
    if login_dialog.exec() == QDialog.DialogCode.Accepted and login_dialog.accepted:
        window = MainWindow()
        window.show()
        sys.exit(app.exec())
    else:
        sys.exit()