from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QComboBox, QLabel, QMessageBox, QLineEdit, QTimeEdit, QCalendarWidget
from PyQt6.QtCore import QDateTime, QDate
from db import get_db_connection

class MatchesWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Správa zápasů")
        self.setGeometry(150, 150, 400, 500)
        layout = QVBoxLayout()

        # Výběr týmů pro nový zápas
        self.team1_combo = QComboBox(self)
        self.team2_combo = QComboBox(self)
        self.load_teams()

        layout.addWidget(QLabel("Tým 1:"))
        layout.addWidget(self.team1_combo)
        layout.addWidget(QLabel("Tým 2:"))
        layout.addWidget(self.team2_combo)

        # Přidání widgetu pro datum a čas
        self.calendar_widget = QCalendarWidget(self)
        self.time_edit = QTimeEdit(self)
        self.time_edit.setDisplayFormat("hh:mm:ss")

        layout.addWidget(QLabel("Datum zápasu:"))
        layout.addWidget(self.calendar_widget)
        layout.addWidget(QLabel("Čas zápasu:"))
        layout.addWidget(self.time_edit)

        self.add_match_btn = QPushButton("Přidat zápas")
        self.add_match_btn.clicked.connect(self.add_match)
        layout.addWidget(self.add_match_btn)

        # Výběr zápasu pro zadání výsledku
        self.match_combo = QComboBox(self)
        self.load_matches()

        layout.addWidget(QLabel("Vyber zápas:"))
        layout.addWidget(self.match_combo)

        self.score1_input = QLineEdit(self)
        self.score1_input.setPlaceholderText("Góly tým 1")
        layout.addWidget(self.score1_input)

        self.score2_input = QLineEdit(self)
        self.score2_input.setPlaceholderText("Góly tým 2")
        layout.addWidget(self.score2_input)

        self.add_result_btn = QPushButton("Zadat výsledek")
        self.add_result_btn.clicked.connect(self.add_result)
        layout.addWidget(self.add_result_btn)

        self.setLayout(layout)
        print("MatchesWindow: Inicializace okna dokončena.")

    def load_teams(self):
        """Načtení týmů do ComboBoxu."""
        print("load_teams: Spouštím načítání týmů...")
        conn = get_db_connection()
        if not conn:
            print("load_teams: Nepodařilo se získat připojení k databázi.")
            return

        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM `1teams`")
        teams = cursor.fetchall()
        print("load_teams: Načtené týmy:", teams)
        cursor.close()
        conn.close()

        for team in teams:
            self.team1_combo.addItem(team[1], team[0])
            self.team2_combo.addItem(team[1], team[0])
        print("load_teams: Týmy načteny do ComboBoxů.")

    def load_matches(self):
        """Načtení zápasů do ComboBoxu pro zadání výsledku."""
        print("load_matches: Spouštím načítání zápasů...")
        conn = get_db_connection()
        if not conn:
            print("load_matches: Nepodařilo se získat připojení k databázi.")
            return

        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.id, t1.name, t2.name, m.match_date
            FROM `1matches` m
            JOIN `1teams` t1 ON m.team1_id = t1.id
            JOIN `1teams` t2 ON m.team2_id = t2.id
            WHERE m.score_team1 IS NULL  -- Přidána podmínka pro filtrování zápasů bez skóre
            ORDER BY m.match_date DESC
            LIMIT 10
        """)
        matches = cursor.fetchall()
        print("load_matches: Načtené zápasy:", matches)
        cursor.close()
        conn.close()

        self.match_combo.clear()
        for match in matches:
            match_id, team1, team2, date = match
            match_text = f"{team1} vs. {team2} ({date})"
            self.match_combo.addItem(match_text, match_id)
        print("load_matches: Zápasy načteny do ComboBoxu.")

    def add_match(self):
        """Přidání zápasu."""
        print("add_match: Spouštím přidání zápasu...")
        team1_id = self.team1_combo.currentData()
        team2_id = self.team2_combo.currentData()
        print("add_match: ID týmu 1:", team1_id, "ID týmu 2:", team2_id)

        if team1_id == team2_id:
            QMessageBox.warning(self, "Chyba", "Tým nemůže hrát proti sobě!")
            return

        # Získání data a času z widgetů
        match_date = self.calendar_widget.selectedDate().toString("yyyy-MM-dd")
        match_time = self.time_edit.time().toString("hh:mm:ss")
        match_datetime = f"{match_date} {match_time}"

        conn = get_db_connection()
        if not conn:
            print("add_match: Nepodařilo se získat připojení k databázi.")
            return

        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO `1matches` (team1_id, team2_id, match_date)
                VALUES (%s, %s, %s)
            """, (team1_id, team2_id, match_date))
            conn.commit()
            print("add_match: Zápas přidán do databáze.")
            QMessageBox.information(self, "Úspěch", "Zápas byl přidán!")
            self.load_matches()
        except Exception as e:
            QMessageBox.critical(self, "Chyba", f"Chyba při přidávání zápasu:\n{e}")
            print("add_match: Chyba při přidávání zápasu:", e)
        cursor.close()
        conn.close()
        print("add_match: Přidání zápasu dokončeno.")

    def add_result(self):
        """Zadání skóre zápasu."""
        print("add_result: Spouštím zadání výsledku...")
        match_id = self.match_combo.currentData()
        score1 = self.score1_input.text()
        score2 = self.score2_input.text()
        print("add_result: ID zápasu:", match_id, "Skóre 1:", score1, "Skóre 2:", score2)

        if not score1.isdigit() or not score2.isdigit():
            QMessageBox.warning(self, "Chyba", "Zadejte platné číslo pro skóre!")
            return

        conn = get_db_connection()
        if not conn:
            print("add_result: Nepodařilo se získat připojení k databázi.")
            return

        cursor = conn.cursor()
        try:
            cursor.execute("UPDATE `1matches` SET score_team1 = %s, score_team2 = %s WHERE id = %s",
                           (score1, score2, match_id))
            conn.commit()
            print("add_result: Výsledek uložen do databáze.")
            QMessageBox.information(self, "Úspěch", "Výsledek byl uložen!")
            self.load_matches()
        except Exception as e:
            QMessageBox.critical(self, "Chyba", f"Chyba při ukládání výsledku:\n{e}")
            print("add_result: Chyba při ukládání výsledku:", e)
        cursor.close()
        conn.close()
        print("add_result: Zadání výsledku dokončeno.")