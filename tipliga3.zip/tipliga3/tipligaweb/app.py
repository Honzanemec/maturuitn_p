from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from db import get_db_connection

app = Flask(__name__)
app.secret_key = "tajnyklic"  # Pro správu session

@app.route("/base")
def base():
    return render_template("base.html")  # Ujisti se, že existuje soubor templates/rozcesti.html


@app.route("/")
def index():
    """Hlavní stránka"""
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Registrace hráče"""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO `1users` (username, password) VALUES (%s, %s)", (username, password))
            conn.commit()
            return redirect(url_for("login"))
        except mysql.connector.Error as e:
            return f"Chyba při registraci: {e}"
        finally:
            cursor.close()
            conn.close()

    return render_template("register.html")


@app.route("/add_result", methods=["POST"])
def add_result():
    """Přidání výsledku zápasu a přepočítání bodů"""
    match_id = request.form["match_id"]
    score1 = request.form["score1"]
    score2 = request.form["score2"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE `1matches` SET score_team1 = %s, score_team2 = %s WHERE id = %s",
                   (score1, score2, match_id))
    conn.commit()

    update_points()  # ✅ Přepočítání bodů po aktualizaci výsledku

    cursor.close()
    conn.close()

    flash("Výsledek byl uložen a body byly aktualizovány!", "success")
    return redirect(url_for("vysledky"))




@app.route("/login", methods=["GET", "POST"])
def login():
    """Přihlášení hráče"""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM `1users` WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user:
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("base"))
        else:
            return "Neplatné přihlašovací údaje!"

    return render_template("login.html")




@app.route("/moje_tipy")
def moje_tipy():
    """Zobrazení posledních tipů přihlášeného hráče"""
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT t1.name AS team1, t2.name AS team2, p.predicted_score_team1, p.predicted_score_team2,
               m.score_team1, m.score_team2, p.points_awarded
        FROM `1predictions` p
        JOIN `1matches` m ON p.match_id = m.id
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE p.user_id = %s
        ORDER BY m.match_date DESC  -- Seřadíme od nejnovějších zápasů
        LIMIT 10                 -- Omezíme počet zobrazených tipů na 10 (můžeš upravit)
    """, (user_id,))
    
    predictions = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template("moje_tipy.html", predictions=predictions)

@app.route("/logout")
def logout():
    """Odhlášení uživatele"""
    session.pop("user_id", None)
    session.pop("username", None)
    return redirect(url_for("index"))


@app.route("/tabulka")
def tabulka():
    """Zobrazení tabulky hráčů a jejich bodů"""
    update_points()  # Před zobrazením přepočítáme body
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT username, points FROM `1users` ORDER BY points DESC")
    players = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template("tabulka.html", players=players)


@app.route("/neodehrane_zapasy")
def neodehrane_zapasy():
    """Zobrazí seznam neodehraných zápasů"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT t1.name AS team1, t2.name AS team2, m.match_date
        FROM `1matches` m
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE m.score_team1 IS NULL AND m.score_team2 IS NULL
        ORDER BY m.match_date
    """)

    matches = cursor.fetchall()
    cursor.close()
    conn.close()
    print(matches)
    return render_template("neodehrane_zapasy.html", matches=matches)


def update_points():
    """Přepočítá body hráčů podle správnosti jejich tipů"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Získání všech tipů hráčů a jejich porovnání s výsledky zápasů
    cursor.execute("""
        SELECT p.id, p.user_id, p.match_id, p.predicted_score_team1, p.predicted_score_team2, 
               m.score_team1, m.score_team2
        FROM `1predictions` p
        JOIN `1matches` m ON p.match_id = m.id
        WHERE m.score_team1 IS NOT NULL AND m.score_team2 IS NOT NULL
    """)
    
    predictions = cursor.fetchall()

    for prediction in predictions:
        prediction_id, user_id, match_id, predicted1, predicted2, actual1, actual2 = prediction
        points = 0

        if predicted1 == actual1 and predicted2 == actual2:
            points = 3  # Správné skóre
        elif (predicted1 > predicted2 and actual1 > actual2) or (predicted1 < predicted2 and actual1 < actual2):
            points = 1  # Správný vítěz

        # Aktualizace bodů ve `1predictions`
        cursor.execute("UPDATE `1predictions` SET points_awarded = %s WHERE id = %s",
                       (points, prediction_id))

    # Přepočet celkových bodů hráčů
    cursor.execute("""
        UPDATE `1users` u
        SET u.points = (
            SELECT COALESCE(SUM(p.points_awarded), 0) 
            FROM `1predictions` p 
            WHERE p.user_id = u.id
        )
    """)

    conn.commit()
    cursor.close()
    conn.close()


@app.route("/tipovat", methods=["GET", "POST"])
def tipovat():
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        match_id = request.form["match"]
        tip = request.form["tip"]

        try:
            predicted_score_team1, predicted_score_team2 = map(int, tip.split(":"))
        except ValueError:
            flash("Neplatný formát tipu. Použij formát 'x:y'", "danger")
            return redirect(url_for("tipovat"))

        user_id = session["user_id"]

        try:
            cursor.execute("""
                INSERT INTO `1predictions` (user_id, match_id, predicted_score_team1, predicted_score_team2)
                VALUES (%s, %s, %s, %s)
            """, (user_id, match_id, predicted_score_team1, predicted_score_team2))
            conn.commit()
            flash("Tip uložen!", "success")
            return redirect(url_for("moje_tipy"))
        except mysql.connector.Error as e:
            flash(f"Chyba při ukládání tipu: {e}", "danger")
            return redirect(url_for("tipovat"))

    # Načtení zápasů, které nemají výsledek
    cursor.execute("""
        SELECT m.id, t1.name AS home_team, t2.name AS away_team
        FROM `1matches` m
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE m.score_team1 IS NULL AND m.score_team2 IS NULL  -- Přidána podmínka
    """)
    matches = cursor.fetchall()

    if not matches:
        flash("Momentálně nejsou žádné dostupné zápasy pro tipování.", "warning")

    cursor.close()
    conn.close()

    return render_template("tipovat.html", matches=matches)

@app.route("/vysledky")
def vysledky():
    """Zobrazí výsledky zápasů"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT t1.name AS team1, t2.name AS team2, m.score_team1, m.score_team2, m.match_date
        FROM `1matches` m
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE m.score_team1 IS NOT NULL AND m.score_team2 IS NOT NULL
        ORDER BY m.match_date DESC
    """)

    matches = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("vysledky.html", matches=matches)


if __name__ == "__main__":
    app.run(debug=True)
