from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
import bcrypt
import re
from db import get_db_connection

app = Flask(__name__)
app.secret_key = "tajnyklic"  # Pro správu session


def vypocitej_statistiku_tipu(user_id):
    """Vypočítá statistiku úspěšnosti tipů pro daného uživatele."""

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT 
            p.predicted_score_team1, p.predicted_score_team2,
            m.score_team1, m.score_team2, p.points_awarded
        FROM `1predictions` p
        JOIN `1matches` m ON p.match_id = m.id
        WHERE p.user_id = %s
    """, (user_id,))

    predictions = cursor.fetchall()

    celkovy_pocet_tipu = len(predictions)
    pocet_spravnych_tipu_skore = 0
    pocet_spravnych_tipu_vitez = 0
    celkem_ziskanych_bodu = 0

    for tip in predictions:
        predicted_team1 = tip["predicted_score_team1"]
        predicted_team2 = tip["predicted_score_team2"]
        actual_team1 = tip["score_team1"]
        actual_team2 = tip["score_team2"]
        points_awarded = tip["points_awarded"]

        if actual_team1 is not None and actual_team2 is not None:  # Počítáme jen tipy, kde je znám výsledek
            if predicted_team1 == actual_team1 and predicted_team2 == actual_team2:
                pocet_spravnych_tipu_skore += 1
                pocet_spravnych_tipu_vitez += 1  # Pokud je správné skóre, je i správný vítěz
            elif (predicted_team1 > predicted_team2 and actual_team1 > actual_team2) or \
                 (predicted_team1 < predicted_team2 and actual_team1 < actual_team2):
                pocet_spravnych_tipu_vitez += 1
            
            celkem_ziskanych_bodu += points_awarded

    cursor.close()
    conn.close()

    if celkovy_pocet_tipu > 0:
        procento_uspesnosti_skore = (pocet_spravnych_tipu_skore / celkovy_pocet_tipu) * 100
        procento_uspesnosti_vitez = (pocet_spravnych_tipu_vitez / celkovy_pocet_tipu) * 100
        prumerny_pocet_bodu_na_tip = celkem_ziskanych_bodu / celkovy_pocet_tipu
    else:
        procento_uspesnosti_skore = 0
        procento_uspesnosti_vitez = 0
        prumerny_pocet_bodu_na_tip = 0

    return {
        "celkovy_pocet_tipu": celkovy_pocet_tipu,
        "pocet_spravnych_tipu_skore": pocet_spravnych_tipu_skore,
        "pocet_spravnych_tipu_vitez": pocet_spravnych_tipu_vitez,
        "procento_uspesnosti_skore": procento_uspesnosti_skore,
        "procento_uspesnosti_vitez": procento_uspesnosti_vitez,
        "prumerny_pocet_bodu_na_tip": prumerny_pocet_bodu_na_tip
    }


@app.route("/profil/<username>")  # Přidáme route pro profil
def profil(username):
    """Zobrazí profil hráče a jeho statistiky."""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM `1users` WHERE username = %s", (username,))
    user = cursor.fetchone()

    if not user:
        return "Uživatel nenalezen", 404  # Zde by bylo vhodné zobrazit nějakou uživatelsky přívětivou stránku s chybou

    statistika = vypocitej_statistiku_tipu(user["id"])

    cursor.close()
    conn.close()

    return render_template("profil.html", user=user, statistika=statistika)


@app.route("/base")
def base():
    return render_template("base.html")  # Ujisti se, že existuje soubor templates/rozcesti.html


@app.route("/")
def index():
    """Hlavní stránka"""
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Registrace hráče"""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            # Hashování hesla pomocí bcrypt
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

            cursor.execute("INSERT INTO `1users` (username, password) VALUES (%s, %s)", (username, hashed_password))  # Ukládáme hash
            conn.commit()
            return redirect(url_for("login"))
        except mysql.connector.Error as e:
            return f"Chyba při registraci: {e}"
        finally:
            cursor.close()
            conn.close()

    return render_template("register.html")


@app.route("/add_result", methods=["POST"])
def add_result():
    """Přidání výsledku zápasu a přepočítání bodů"""
    match_id = request.form["match_id"]
    score1 = request.form["score1"]
    score2 = request.form["score2"]

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("UPDATE `1matches` SET score_team1 = %s, score_team2 = %s WHERE id = %s",
                   (score1, score2, match_id))
    conn.commit()

    update_points()  # ✅ Přepočítání bodů po aktualizaci výsledku

    cursor.close()
    conn.close()

    flash("Výsledek byl uložen a body byly aktualizovány!", "success")
    return redirect(url_for("vysledky"))




@app.route("/login", methods=["GET", "POST"])
def login():
    """Přihlášení hráče"""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        try:
            cursor.execute("SELECT * FROM `1users` WHERE username = %s", (username,))
            user = cursor.fetchone()

            if user:
                stored_hash = user["password"].encode('utf-8')  # Načteme hash z databáze a zakódujeme na bytes
                if bcrypt.checkpw(password.encode('utf-8'), stored_hash):
                    # Přihlášení úspěšné
                    session["user_id"] = user["id"]
                    session["username"] = user["username"]
                    return redirect(url_for("base"))
                else:
                    return "Neplatné přihlašovací údaje!"
            else:
                return "Uživatel nenalezen!"
        except mysql.connector.Error as e:
            return f"Chyba při přihlašování: {e}"
        finally:
            cursor.close()
            conn.close()

    return render_template("login.html")




@app.route("/moje_tipy")
def moje_tipy():
    """Zobrazení posledních tipů přihlášeného hráče"""
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT t1.name AS team1, t2.name AS team2, p.predicted_score_team1, p.predicted_score_team2,
               m.score_team1, m.score_team2, p.points_awarded
        FROM `1predictions` p
        JOIN `1matches` m ON p.match_id = m.id
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE p.user_id = %s
        ORDER BY m.match_date DESC  -- Seřadíme od nejnovějších zápasů
        LIMIT 10                 -- Omezíme počet zobrazených tipů na 10 (můžeš upravit)
    """, (user_id,))
    
    predictions = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template("moje_tipy.html", predictions=predictions)

@app.route("/logout")
def logout():
    """Odhlášení uživatele"""
    session.pop("user_id", None)
    session.pop("username", None)
    return redirect(url_for("index"))


@app.route("/tabulka")
def tabulka():
    """Zobrazení tabulky hráčů a jejich bodů"""
    update_points()  # Před zobrazením přepočítáme body
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("SELECT username, points FROM `1users` ORDER BY points DESC")
    players = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template("tabulka.html", players=players)


@app.route("/neodehrane_zapasy")
def neodehrane_zapasy():
    """Zobrazí seznam neodehraných zápasů"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT t1.name AS team1, t2.name AS team2, m.match_date
        FROM `1matches` m
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE m.score_team1 IS NULL AND m.score_team2 IS NULL
        ORDER BY m.match_date
    """)

    matches = cursor.fetchall()
    cursor.close()
    conn.close()
    print(matches)
    return render_template("neodehrane_zapasy.html", matches=matches)


def update_points():
    """Přepočítá body hráčů podle správnosti jejich tipů"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Získání všech tipů hráčů a jejich porovnání s výsledky zápasů
    cursor.execute("""
        SELECT p.id, p.user_id, p.match_id, p.predicted_score_team1, p.predicted_score_team2, 
               m.score_team1, m.score_team2
        FROM `1predictions` p
        JOIN `1matches` m ON p.match_id = m.id
        WHERE m.score_team1 IS NOT NULL AND m.score_team2 IS NOT NULL
    """)
    
    predictions = cursor.fetchall()

    for prediction in predictions:
        prediction_id, user_id, match_id, predicted1, predicted2, actual1, actual2 = prediction
        points = 0

        if predicted1 == actual1 and predicted2 == actual2:
            points = 3  # Správné skóre
        elif (predicted1 > predicted2 and actual1 > actual2) or (predicted1 < predicted2 and actual1 < actual2):
            points = 1  # Správný vítěz

        # Aktualizace bodů ve `1predictions`
        cursor.execute("UPDATE `1predictions` SET points_awarded = %s WHERE id = %s",
                       (points, prediction_id))

    # Přepočet celkových bodů hráčů
    cursor.execute("""
        UPDATE `1users` u
        SET u.points = (
            SELECT COALESCE(SUM(p.points_awarded), 0) 
            FROM `1predictions` p 
            WHERE p.user_id = u.id
        )
    """)

    conn.commit()
    cursor.close()
    conn.close()


@app.route("/tipovat", methods=["GET", "POST"])
def tipovat():
    """Zobrazení stránky pro tipování zápasů a uložení tipu."""
    if "user_id" not in session:
        return redirect(url_for("login"))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        # ... (zpracování odeslaného tipu - BEZ ZMĚN)
        match_id = request.form.get("match")
        tip = request.form.get("tip")

        print(f"Uživatel {session['user_id']} tipuje zápas {match_id} s tipem {tip}")

        if not match_id or not tip:
            flash("Chyba: Nebyly zadány všechny údaje.", "danger")
            return redirect(url_for("tipovat"))

        # Validace formátu tipu (volitelné, ale doporučeno)
        if not re.match(r"^\d+:\d+$", tip):
            flash("Chyba: Neplatný formát tipu. Zadejte prosím ve tvaru 'x:y'.", "danger")
            return redirect(url_for("tipovat"))

        try:
            # Kontrola, zda uživatel už tip na tento zápas zadal
            cursor.execute("SELECT id FROM `1predictions` WHERE user_id = %s AND match_id = %s",
                           (session["user_id"], match_id))
            existing_prediction = cursor.fetchone()
            if existing_prediction:
                flash("Tip na tento zápas jste již zadal/a.", "warning")
                return redirect(url_for("tipovat"))

            # Uložení tipu do databáze
            cursor.execute("""
                INSERT INTO `1predictions` (user_id, match_id, predicted_score_team1, predicted_score_team2)
                VALUES (%s, %s, %s, %s)
            """, (session["user_id"], match_id, tip.split(":")[0], tip.split(":")[1]))
            conn.commit()
            flash("Tip byl úspěšně uložen!", "success")
            return redirect(url_for("moje_tipy"))
        except mysql.connector.Error as e:
            print(f"Chyba při zápisu tipu do databáze: {e}")
            print(f"Chyba: {e}")
            flash("Chyba při ukládání tipu.", "danger")
            return redirect(url_for("tipovat"))
        finally:
            cursor.close()
            conn.close()

    else:
        # Zobrazení stránky pro tipování (GET request)
        # Načtení pouze zápasů, na které uživatel ještě nevsadil A které nemají výsledek
        cursor.execute("""
            SELECT 
                m.id,
                t1.name AS home_team, 
                t2.name AS away_team,
                m.match_date
            FROM `1matches` m
            JOIN `1teams` t1 ON m.team1_id = t1.id
            JOIN `1teams` t2 ON m.team2_id = t2.id
            WHERE NOT EXISTS (
                SELECT 1 FROM `1predictions` p 
                WHERE p.user_id = %s AND p.match_id = m.id
            )
            AND m.score_team1 IS NULL  
            AND m.score_team2 IS NULL  
        """, (session["user_id"],))
        matches = cursor.fetchall()

        if not matches:
            flash("Momentálně nejsou žádné dostupné zápasy pro tipování.", "warning")

        cursor.close()
        conn.close()

        return render_template("tipovat.html", matches=matches)

@app.route("/info")
def info():
    """Zobrazení informační stránky."""
    return render_template("info.html")

    
@app.route("/vysledky")
def vysledky():
    """Zobrazí výsledky zápasů"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT t1.name AS team1, t2.name AS team2, m.score_team1, m.score_team2, m.match_date
        FROM `1matches` m
        JOIN `1teams` t1 ON m.team1_id = t1.id
        JOIN `1teams` t2 ON m.team2_id = t2.id
        WHERE m.score_team1 IS NOT NULL AND m.score_team2 IS NOT NULL
        ORDER BY m.match_date DESC
    """)

    matches = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("vysledky.html", matches=matches)


if __name__ == "__main__":
    app.run(debug=True)
