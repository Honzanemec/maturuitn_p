import bcrypt

def vytvor_uzivatele(username, password):
    """Vytvoří uživatele a uloží jeho jméno a zahashované heslo."""
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    try:
        with open("users.txt", "a") as file:
            file.write(f"{username}:{hashed_password}\n")
    except Exception as e:
        print(f"Chyba při ukládání uživatele: {e}")

# Použití:
# vytvor_uzivatele("novy_uzivatel", "moje_tajne_heslo")