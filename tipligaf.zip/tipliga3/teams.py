from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLineEdit, QLabel, QMessageBox, QListWidget
from db import get_db_connection

class TeamsWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Správa týmů")
        self.setGeometry(150, 150, 400, 400)

        layout = QVBoxLayout()

        self.team_input = QLineEdit(self)
        self.team_input.setPlaceholderText("Zadej název týmu")
        layout.addWidget(self.team_input)

        self.add_team_btn = QPushButton("Přidat tým")
        self.add_team_btn.clicked.connect(self.add_team)
        layout.addWidget(self.add_team_btn)

        self.teams_list = QListWidget(self)
        layout.addWidget(self.teams_list)

        self.delete_team_btn = QPushButton("Smazat tým")
        self.delete_team_btn.clicked.connect(self.delete_team)
        layout.addWidget(self.delete_team_btn)

        self.setLayout(layout)
        self.load_teams()

    def load_teams(self):
        """Načtení seznamu týmů do ListWidgetu."""
        conn = get_db_connection()
        if not conn:
            return

        cursor = conn.cursor()
        cursor.execute("SELECT id, name FROM `1teams`")
        teams = cursor.fetchall()
        cursor.close()
        conn.close()

        self.teams_list.clear()
        for team in teams:
            self.teams_list.addItem(f"{team[0]} - {team[1]}")

    def add_team(self):
        """Přidání nového týmu."""
        team_name = self.team_input.text().strip()
        if not team_name:
            QMessageBox.warning(self, "Chyba", "Musíš zadat název týmu!")
            return

        conn = get_db_connection()
        if not conn:
            return

        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO `1teams` (name) VALUES (%s)", (team_name,))
            conn.commit()
            QMessageBox.information(self, "Úspěch", f"Tým '{team_name}' byl přidán!")
            self.load_teams()
        except Exception as e:
            QMessageBox.critical(self, "Chyba", f"Chyba při přidávání týmu:\n{e}")
        cursor.close()
        conn.close()

    def delete_team(self):
        """Smazání vybraného týmu."""
        selected_item = self.teams_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Chyba", "Musíš vybrat tým!")
            return

        team_id = selected_item.text().split(" - ")[0]

        conn = get_db_connection()
        if not conn:
            return

        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM `1teams` WHERE id = %s", (team_id,))
            conn.commit()
            QMessageBox.information(self, "Úspěch", "Tým byl smazán!")
            self.load_teams()
        except Exception as e:
            QMessageBox.critical(self, "Chyba", f"Chyba při mazání týmu:\n{e}")
        cursor.close()
        conn.close()
