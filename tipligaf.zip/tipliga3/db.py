import mysql.connector

DB_HOST = "dbs.spskladno.cz"
DB_USER = "student10"
DB_PASSWORD = "spsnet"
DB_NAME = "vyuka10"

def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME
        )
        return conn
    except mysql.connector.Error as e:
        print(f"❌ Chyba připojení k databázi: {e}")
        return None